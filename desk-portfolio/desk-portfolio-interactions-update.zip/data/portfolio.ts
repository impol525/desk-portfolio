export interface Project {
  title: string;
  description: string;
  tags: string[];
  href?: string;
}

export interface StackGroup {
  group: string;
  items: string[];
}

export interface ContactLink {
  label: string;
  href: string;
}

export const portfolio = {
  name: "John Ray G. Hermocilla",
  role: "Full-stack developer",
  school: "BS Information Technology, NEUST",
  about: [
    "I'm a 4th-year BS Information Technology student at Nueva Ecija University of Science and Technology (NEUST), based in Cabanatuan City.",
    "I build mobile, web and cloud-based systems, from Ionic and Angular apps backed by Firebase to Next.js sites and PHP/MySQL back ends.",
  ],
  projects: [
    {
      title: "Bongabon LifeLink",
      description:
        "Capstone thesis: a platform that coordinates incident reports and responders for the MDRRMO of Bongabon, Nueva Ecija.",
      tags: ["Firebase", "Firestore", "Cloud Messaging", "Real-time maps"],
    },
    {
      title: "SnapAttend",
      description: "A mobile attendance app, tested on physical Android devices.",
      tags: ["Ionic", "Angular", "Capacitor", "Firebase"],
    },
    {
      title: "Barangay Sari-Sari Store Tycoon",
      description: "A Roblox tycoon game where you run and grow a Filipino neighborhood store.",
      tags: ["Roblox Studio", "Game design"],
    },
  ] satisfies Project[],
  stack: [
    { group: "Frontend", items: ["Angular", "Ionic", "React", "Next.js", "Tailwind CSS", "Three.js"] },
    { group: "Backend and cloud", items: ["Firebase", "Firestore", "Cloud Functions", "PHP", "MySQL"] },
    { group: "Mobile and tools", items: ["Capacitor", "Git", "Vercel", "Roblox Studio"] },
  ] satisfies StackGroup[],
  contact: {
    email: "hermocillajohnray821@gmail.com",
    phone: "09957316886",
    phoneIntl: "+639957316886",
    location: "Macatbong, Cabanatuan City",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Macatbong+Cabanatuan+City",
    // Add GitHub / LinkedIn / Facebook here when you want them shown.
    links: [] as ContactLink[],
  },
};
