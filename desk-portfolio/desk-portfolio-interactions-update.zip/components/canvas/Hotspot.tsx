"use client";

import { useRef, useState, type ReactNode } from "react";
import { useFrame, type ThreeEvent } from "@react-three/fiber";
import { Html, useCursor } from "@react-three/drei";
import { easing } from "maath";
import type { Group } from "three";
import type { Vec3 } from "@/data/views";
import { playSfx } from "@/lib/sound";
import { useStore, type ViewId } from "@/store/useStore";

interface HotspotProps {
  /** Opens this view (camera zoom + panel). */
  id?: Exclude<ViewId, "home">;
  /** Or run any action, for example toggling the lamp. */
  onSelect?: () => void;
  label: string;
  position: Vec3;
  rotation?: Vec3;
  /** Height of the floating label above the group origin. */
  labelHeight?: number;
  children: ReactNode;
}

/**
 * Wraps any model (primitive today, .glb later) with hover + click behaviour.
 * The model itself never needs to know about the camera or the store.
 */
export function Hotspot({ id, onSelect, label, position, rotation, labelHeight = 1, children }: HotspotProps) {
  const ref = useRef<Group>(null);
  const [hovered, setHovered] = useState(false);
  const view = useStore((s) => s.view);
  const setView = useStore((s) => s.setView);

  const interactive = view === "home";
  const active = hovered && interactive;
  useCursor(active);

  useFrame((_, delta) => {
    if (!ref.current) return;
    const s = active ? 1.04 : 1;
    easing.damp3(ref.current.scale, [s, s, s], 0.15, delta);
  });

  const onOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    if (!hovered && interactive) playSfx("hover");
    setHovered(true);
  };

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (!interactive) return;
    playSfx("click");
    if (id) setView(id);
    onSelect?.();
  };

  return (
    <group
      ref={ref}
      position={position}
      rotation={rotation}
      onPointerOver={onOver}
      onPointerOut={() => setHovered(false)}
      onClick={onClick}
    >
      {children}
      {active && (
        <Html position={[0, labelHeight, 0]} center zIndexRange={[20, 0]} style={{ pointerEvents: "none" }}>
          <div className="glass whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-medium">{label}</div>
        </Html>
      )}
    </group>
  );
}
