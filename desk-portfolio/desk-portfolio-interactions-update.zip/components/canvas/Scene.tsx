"use client";

import { Canvas } from "@react-three/fiber";
import { ContactShadows, Environment, Lightformer, PerspectiveCamera, Sparkles } from "@react-three/drei";
import { VIEWS } from "@/data/views";
import { useStore } from "@/store/useStore";
import { CameraRig } from "./CameraRig";
import { Hotspot } from "./Hotspot";
import { Room } from "./Room";
import { BookStack, Desk, Keyboard, Lamp, Monitor, Mouse, Mug, Notebook, Phone, Plant, SpinChair } from "./models";

const BACKGROUND = { dark: "#0d1020", light: "#e4e9f4" };

function Lights() {
  const dark = useStore((s) => s.theme === "dark");

  return (
    <>
      <ambientLight intensity={dark ? 0.55 : 0.6} />
      <hemisphereLight args={[dark ? "#8da2ff" : "#ffffff", "#3a2f45", dark ? 0.6 : 0.5]} />
      <directionalLight
        castShadow
        position={[5, 8, 4]}
        color={dark ? "#c9d4ff" : "#fff3e0"}
        intensity={dark ? 1.0 : 1.9}
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={1}
        shadow-camera-far={25}
        shadow-camera-left={-6}
        shadow-camera-right={6}
        shadow-camera-top={6}
        shadow-camera-bottom={-6}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
      />
      {/* Procedural environment: no HDR download, reflections still look good. */}
      <Environment resolution={256} frames={1} environmentIntensity={dark ? 0.45 : 0.7}>
        <Lightformer form="rect" intensity={2.5} position={[0, 6, -4]} scale={[10, 4, 1]} />
        <Lightformer form="rect" intensity={1.5} position={[-6, 2, 3]} rotation-y={Math.PI / 2} scale={[8, 4, 1]} />
        <Lightformer form="circle" intensity={2} position={[5, 3, 5]} scale={4} color="#9ec5ff" />
      </Environment>
    </>
  );
}

export default function Scene() {
  const theme = useStore((s) => s.theme);
  const toggleLamp = useStore((s) => s.toggleLamp);
  const kickChair = useStore((s) => s.kickChair);

  return (
    <Canvas shadows dpr={[1, 2]} gl={{ antialias: true }}>
      <color attach="background" args={[BACKGROUND[theme]]} />
      <PerspectiveCamera makeDefault fov={30} near={0.1} far={60} position={VIEWS.home.position} />
      <CameraRig />
      <Lights />

      <Room />
      <Desk />
      <Keyboard position={[0, 1.03, 0.4]} />
      <Mouse position={[0.85, 1.03, 0.42]} rotation={[0, 0.15, 0]} />
      <Mug position={[-0.95, 1, 0.05]} />

      <Plant position={[3.1, 0, -1.0]} />

      <ContactShadows position={[0.3, 0.02, 0.9]} opacity={0.4} scale={9} blur={2.5} far={3} frames={1} />
      <Sparkles count={40} scale={[6, 3, 4]} position={[0.3, 2, 0.8]} size={2} speed={0.25} opacity={0.35} />

      <Hotspot label="Desk lamp" position={[1.65, 1, -0.7]} labelHeight={1.05} onSelect={toggleLamp}>
        <Lamp />
      </Hotspot>

      <Hotspot label="Spin the chair" position={[0.9, 0, 1.75]} rotation={[0, Math.PI + 0.55, 0]} labelHeight={1.35} onSelect={kickChair}>
        <SpinChair />
      </Hotspot>

      <Hotspot id="projects" label="Projects" position={[0, 1, -0.5]} labelHeight={2.1}>
        <Monitor />
      </Hotspot>

      <Hotspot id="about" label="About me" position={[-1.3, 1, 0.5]} rotation={[0, 0.3, 0]} labelHeight={0.5}>
        <Notebook />
      </Hotspot>

      <Hotspot id="stack" label="Tech stack" position={[-1.6, 1, -0.6]} labelHeight={0.6}>
        <BookStack />
      </Hotspot>

      <Hotspot id="contact" label="Contact" position={[1.5, 1, 0.5]} rotation={[0, -0.4, 0]} labelHeight={0.5}>
        <Phone />
      </Hotspot>
    </Canvas>
  );
}
